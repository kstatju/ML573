Readme file to run the code for Lab 2. Please let me know if you have any questions or if you find any problem. 

There are three (3) code files for this lab 2.

	1.  kanak_lab2_q1a.py		if "train_model = False", it will not fit models for all parameters, 
					it will use the csv file contains results for all parameters.

	2.  kanak_lab2_q1b.py		if "train_model = False", it will not fit models for all parameters, 
					it will use the csv file contains results for all parameters.

	3.  kanak_lab2_q2.py		if "train_model = False", it will not fit models for all parameters, 
					it will use the csv file contains results for all parameters.

All are python code files.

1. Python:  python 3.7.6 (default, Jan  8 2020, 20:23:39) [MSC v.1916 64 bit (AMD64)]
	
	Packages:
		numpy 1.18.1
		pandas 1.0.1
		sklearn 0.22.1
		matplotlib 3.1.3
		keras 2.3.1
		re 2.2.1
		sys
		gc
		time
		itertools


2. Run form Windows: juse use the file name to run code from windows cmd (I have used jpyter notebook) 


3. Specify how to change the parameters (listed in task (a) in the project description) in your code, including files and lines.

	1.  for task (1a)	kanak_lab2_q1a.py	Line number: 92 - 100		time to fit for included parameters: >20 hours in my laptop
	2.  for task (1b)	kanak_lab2_q1b.py	Line number: 93 - 101		time to fit for included parameters: >20 hours in my laptop
	3.  for task (2)	kanak_lab2_q2.py	Line number: 101 - 110		time to fit for included parameters: >20 hours in my laptop


4. Report file: Attached pdf (pdf file contains code, output and comments. 
	Don't know how to hide code when export jupyter notebook as pdf.)


5. Submission:  Submit a single zip file Lab2_Choudhury_Kanak.zip containing: 
	(1)  Code:
		1.  kanak_lab2_q1a.py
		2.  kanak_lab2_q1b.py
		3.  kanak_lab2_q2.py

	(2) Readme 

	(3) Report (pdf)

	(4) Data

	(5) 3 csv files (res_1a.csv, res_1b.csv and res_2.csv) contain results for all parameter combinations.  
