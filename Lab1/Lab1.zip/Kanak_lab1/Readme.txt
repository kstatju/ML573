Info to run code:


1. These are Python code (Version: Python 3.7.4 64-bit | Qt 5.9.6 | PyQt5 5.9.2 | Windows 10).

2. Two files have been attached (python files for MLE and NBE)

3. Just need to run the code. It will show the results for classification of test and 
   train data with prior probability. It may take more than 30 min to run.
