Readme file to run the code for Lab 4. Please let me know if you have any questions or if you find any problem. 

There are three (2) code files for this lab 4.

	1.  kanak_lab4_q1.py
	2.  kanak_lab4_q2.py

All are python code files.

1. Python:  python 3.6.9 |Anaconda, Inc.| (default, Jul 30 2019, 14:00:49) [MSC v.1915 64 bit (AMD64)]
	
	Packages:
		python 3.6.9 |Anaconda, Inc.| (default, Jul 30 2019, 14:00:49) [MSC v.1915 64 bit (AMD64)]
		numpy 1.16.5
		pandas 0.25.1
		sklearn 0.21.3
		matplotlib 3.1.1
		re 2.2.1


2. Run form Windows: juse use the file name to run code from windows cmd (I have used jpyter notebook) 


3. Report file: Attached pdf (pdf file contains code, output and comments. 
	Don't know how to hide code when export jupyter notebook as pdf.)


4. Submission:  Submit a single zip file Lab4_Choudhury_Kanak.zip containing: 
	(1)  Code:
		1.  kanak_lab4_q1.py
		2.  kanak_lab4_q2.py

	(2) Readme 

	(3) Report (pdf)

	(4) Data

